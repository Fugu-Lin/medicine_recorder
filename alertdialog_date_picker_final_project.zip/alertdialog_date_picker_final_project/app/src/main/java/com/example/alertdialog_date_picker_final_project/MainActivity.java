package com.example.alertdialog_date_picker_final_project;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.github.clans.fab.FloatingActionButton;

import java.io.File;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton fab;
    RecyclerView recyclerView;
    Calendar calendar;
    DatePickerDialog datePickerDialog;

    String result_image_path = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fab = findViewById(R.id.menu_item);


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                final View v = inflater.inflate(R.layout.add_something, null);
                final AlertDialog alertD = new AlertDialog.Builder(MainActivity.this).
                        setNegativeButton("離開", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        }).setPositiveButton("確定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        }).create();

                alertD.setTitle("輸入事件");
                alertD.setView(v);

                Button date_picker = (v.findViewById(R.id.button));
                Button time_picker = (v.findViewById(R.id.button2));
                Button take_photo = (v.findViewById(R.id.button3));

                final EditText show_date_picker = (v.findViewById(R.id.editText));
                final EditText show_time_picker = (v.findViewById(R.id.editText2));

                date_picker.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Log.d("AAAAAAAAAAA","OK");
                        final Calendar c = Calendar.getInstance();

                        DatePickerDialog dpd = new DatePickerDialog(view.getContext(),
                                new DatePickerDialog.OnDateSetListener() {

                                    @Override
                                    public void onDateSet(DatePicker view, int year,
                                                          int monthOfYear, int dayOfMonth) {
                                        show_date_picker.setText(dayOfMonth + "-"
                                                + (monthOfYear + 1) + "-" + year);

                                    }
                                }, c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE));
                        dpd.show();
                    }
                });

                time_picker.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        TimePickerDialog timePickerDialog = new TimePickerDialog(view.getContext(), new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int i, int i1) {
                                show_time_picker.setText(i + "-" + i1);
                            }
                        },0,0,true);
                        timePickerDialog.show();
                    }
                });

                take_photo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this,AndroidCameraApi.class);
                        startActivityForResult(intent,0);
                        File imgFile = new  File(result_image_path);

                        if(imgFile.exists()){
                            Log.d("File_Exists","True!!!!!!!!!!!!!!!!!!!!!!!!!!");
                            ImageView show_image = (v.findViewById(R.id.imageView));
                            Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                            show_image.setImageBitmap(myBitmap);
                        }
                    }
                });
                alertD.show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        result_image_path = data.getExtras().getString("name");
        Log.d("result_image_path",result_image_path);
    }
}
